//npm install express --save
const express = require('express');
const app = express();
var formidable = require('formidable');
//npm install ejs --save
app.set("view engine", "ejs");

app.use(express.urlencoded({ extended: true }));


var contuser1 = 0;
var contuser2 = 0;
var contuser3 = 0;

var username1 = "fpp1";
var userpassword1 = "fpp1";
var username2 = "fpp2";
var userpassword2 = "fpp2";
var username3 = "fpp3";
var userpassword3 = "fpp3";

app.get('/', (req, res) => {
    res.redirect('/login.html');
});

app.get('/login.html', (req, res) => {
    res.sendFile(__dirname + '/login.html');
});

app.post('/login', (req, res) => {
    var loginuser = req.body.user;
    var loginpassword = req.body.senha;
    
    if(loginuser == username1 && loginpassword == username1){
        console.log("fpp1 logadaço");
        contuser1++;
        console.log(contuser1);
        var msg = "User '"+ username1 + "' Logado!";
        res.render("loginejs", { msg: msg});   
    }if(loginuser == username2 && loginpassword == username2){
        console.log("fpp2 logadaço");
        contuser2++;
        console.log(contuser2);
        var msg = "User '"+ username2 + "' Logado!";
        res.render("loginejs", { msg: msg});
    }if(loginuser == username3 && loginpassword == username3){
        console.log("fpp3 logadaço");
        contuser3++;
        console.log(contuser3);
        console.log("user correto!");
        var msg = "User '"+ username3 + "' Logado!";
        res.render("loginejs", { msg: msg});
    }else{
        console.log("user incorreto!");
        var msg = "User Incorreto!";    
        res.render("loginejs", { msg: msg});
    }
});

app.get('/contador', (req, res) => {
    res.writeHead(404,{'Content-Type':'text/html'});
        res.write("Contadores");
        res.write("<br><br>");
        res.write("Usuario: "+username1+"    -    Logou: "+contuser1);
        res.write("<br><br>");
        res.write("Usuario: "+username2+"    -    Logou: "+contuser2);
        res.write("<br><br>");
        res.write("Usuario: "+username3+"    -    Logou: "+contuser3);
        res.write("<br><br><br><br><br><br><br><br><br><br><br><br>");
        res.write("<a href='http://localhost:3000/'><h3>Voltar ao login</h3></a>");
        res.end();
});

app.listen(3000);